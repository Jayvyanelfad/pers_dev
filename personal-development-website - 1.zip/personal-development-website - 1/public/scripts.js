document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', function() {
        alert('Thank you for your interest! Enrollment is currently closed.');
    });
});
