// demo1.js

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('greet').innerText = "Hello, welcome to JavaScript Demo 1!";
});
